CREATE DATABASE projectPI;
USE projectPI;

SET SQL_SAFE_UPDATES = 0;

CREATE TABLE cadastro(
cod_usuario		TINYINT PRIMARY KEY NOT NULL,
cpf 				VARCHAR(14) NOT NULL,
email 				VARCHAR(50) NOT NULL,
numero_do_telefone 	VARCHAR (30)
);

CREATE TABLE posto(
cod_posto		TINYINT PRIMARY KEY NOT NULL,
combustiveis 	VARCHAR(100) NOT NULL,
localizacao 	VARCHAR(50) NOT NULL,
avaliacao			INT(2),
posto			VARCHAR(50) NOT NULL,
CHECK (avaliacao = nota.avaliacao)
);

CREATE TABLE nota(
cod_usuario		TINYINT NOT NULL,
comentario		VARCHAR(150),
nome_doposto		VARCHAR(50) NOT NULL,
avaliacao			INT(2)
);

CREATE TABLE combustivel(
cod_combustivel TINYINT PRIMARY KEY NOT NULL,
preco		VARCHAR(10) NOT NULL,
tipo		VARCHAR(20) NOT NULL
);

ALTER TABLE cadastro ADD CONSTRAINT FK_CADASTRO_POSTO
FOREIGN KEY (cod_usuario) REFERENCES posto(cod_posto) ON DELETE RESTRICT;

ALTER TABLE nota ADD CONSTRAINT FK_NOTA_CADASTRO
FOREIGN KEY (cod_usuario) REFERENCES cadastro(cod_usuario) ON DELETE RESTRICT;

ALTER TABLE posto ADD CONSTRAINT FK_POSTO_COMBUSTIVEL
FOREIGN KEY (cod_posto) REFERENCES combustivel(cod_combustivel) ON DELETE RESTRICT;

SELECT * FROM cliente;
SELECT * FROM posto;
SELECT * FROM nota;
SELECT * FROM combustivel;