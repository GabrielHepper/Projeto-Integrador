import {Combustivel} from "./combustiveis"


export class Posto
{
    posto: Array<string> = []
    localizacao: string
    precos: number
    combustiveis: Array<Combustivel> = []

    constructor(posto: Array<string> = [], localizacao: string, precos: number, 
                combustiveis: Array<Combustivel> = []){

        this.posto = posto
        this.localizacao = localizacao
        this.precos = precos
        this.combustiveis = combustiveis
    }

    addposto(): void{
        
    }

    removePosto(): void{

    }

}