

export class Menu
{
    cadastro: number
    entra: number

    constructor(cadastro: number, entra: number){

        this.cadastro = cadastro
        this.entra = entra
    }

    cadastrar(): void{

    }

    entrar(): void{

    }
}